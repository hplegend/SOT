#define MAXITER 12
